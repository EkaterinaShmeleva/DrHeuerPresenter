﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;

namespace DrHeuerVorstellung.Extensions.HTMLHelperExtensions.Footer
{
    public static class HtmlHelperExtensions
    {
        public static IHtmlContent Footer(this IHtmlHelper htmlHelper, string footerText = "© IT-Akademie Dr. Heuer GmbH 2025", string? backgroundColor = "#ba2b2a", string? textColor = "#c5c3c3", string? additionalHtml = null)
        {
            var sb = new StringBuilder();

            sb.AppendLine($@"
            <footer>
            <div class='container'>
            <p>" + footerText + "</p>");


            if (!string.IsNullOrEmpty(additionalHtml))
            {
                sb.AppendLine(additionalHtml);
            }

            sb.AppendLine("</div></footer>");

            return new HtmlString(sb.ToString());

        }
    }
}