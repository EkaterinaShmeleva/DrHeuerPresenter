﻿using DrHeuerVorstellung.Models;
using Microsoft.AspNetCore.Mvc;

namespace DrHeuerVorstellung.Controllers
{
    public class KontaktController : Controller
    {
        [HttpGet]
        public IActionResult Formular()
        {
            var model = new KontaktViewModel();
            model.FachrichtungListe = new Fachrichtungen();
            return View(model);
        }

        [HttpGet]
        public IActionResult FormularHelper()
        {
            var model = new KontaktViewModel();
            model.FachrichtungListe = new Fachrichtungen();
            return View(model);
        }

        [HttpPost]
        public IActionResult Formular(KontaktViewModel model)
        {
            if (ModelState.IsValid)// Zustand ok
            {
                return View("Bestätigung");
            }
            else
            {
                // Es gibt Fehler → Formular erneut anzeigen mit Fehlermeldungen
                return View(model);
            }
        }
    }
}

