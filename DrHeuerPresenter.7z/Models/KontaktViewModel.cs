﻿using System.ComponentModel.DataAnnotations;

namespace DrHeuerVorstellung.Models
{
    public class KontaktViewModel
    {
        [Required(ErrorMessage = "Name ist erforderlich")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Vorname ist erforderlich")]
        public string? Vorname { get; set; }

        [Required(ErrorMessage = "E-Mail ist erforderlich")]
        [EmailAddress(ErrorMessage = "Ungültige E-Mail-Adresse")]
        public string? Email { get; set; }


        [Required(ErrorMessage = "Nachricht ist erforderlich")]
        public string? Nachricht { get; set; }


        [Required(ErrorMessage = "Bitte wählen Sie einen Standort")]
        public string? Standort { get; set; }

        [Required(ErrorMessage = "Bitte wählen Sie eine Fachrichtung")]
        public Fachrichtungen? FachrichtungListe { get; set; }

        // [Required(ErrorMessage = "Bitte bestätigen Sie die Datenschutzerklärung")]
        [Range(typeof(bool), "true", "true", ErrorMessage = "Bitte akzeptieren Sie die DSGVO.")]
        public bool ZustimmungDSGVO { get; set; }

    }
}
